// This file can contain additional UI logic if needed
